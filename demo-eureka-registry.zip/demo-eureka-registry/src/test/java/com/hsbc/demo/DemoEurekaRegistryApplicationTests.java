package com.hsbc.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEurekaRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
