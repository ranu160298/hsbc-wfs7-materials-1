package com.hsbc.demoeurekaclientaccount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoEurekaClientAccountApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoEurekaClientAccountApplication.class, args);
	}

}
