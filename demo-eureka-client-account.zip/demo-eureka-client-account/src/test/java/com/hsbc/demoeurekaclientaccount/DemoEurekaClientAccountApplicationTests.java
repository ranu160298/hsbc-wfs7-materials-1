package com.hsbc.demoeurekaclientaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoEurekaClientAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
